import numpy as np


# read map from file
# return map, start, goal
def readMapFromText(file):
    with open(file) as f:
        content = f.readlines()
        grid = []
        for line in content:
            list1 = list(line)
            list1 = list1[:-1]  # remove the end line '\n'
            grid.append(list(map(int, list1)))  # string to integer
        grid = np.array(grid)
        
        # find the start
        start = np.where(grid==4)
        start = (start[0][0], start[1][0])

        # find the goal
        goal = np.where(grid==5)
        goal = goal[0][0], goal[1][0]

    return grid, start, goal

